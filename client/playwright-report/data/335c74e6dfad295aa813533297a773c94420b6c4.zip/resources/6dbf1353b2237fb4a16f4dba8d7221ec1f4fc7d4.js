export async function getCities() {
    const response = await fetch("http://localhost:3000/cities");
    if (!response.ok)
        throw new Error("No se pudieron cargar las ciudades.");
    const cities = await response.json();
    if (!Array.isArray(cities) ||
        !cities.every((city) => typeof city === "string")) {
        throw new Error("La respuesta del servidor no contiene una lista de ciudades.");
    }
    return cities;
}
